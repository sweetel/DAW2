package com.pablo.proyectoEntregable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoEntregableApplicationTests {

	@Test
	void contextLoads() {
	}

}
