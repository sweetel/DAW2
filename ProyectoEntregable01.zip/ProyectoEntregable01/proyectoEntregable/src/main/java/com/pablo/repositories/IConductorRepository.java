package com.pablo.repositories;

import com.pablo.models.Conductor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IConductorRepository extends JpaRepository<Conductor, Long> {
    Conductor findByDni(String dni);
}
