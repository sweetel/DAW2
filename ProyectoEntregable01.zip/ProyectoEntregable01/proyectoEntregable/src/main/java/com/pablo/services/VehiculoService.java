package com.pablo.services;

import com.pablo.models.Vehiculo;
import com.pablo.repositories.IVehiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehiculoService {

    @Autowired
    private IVehiculoRepository vehiculoRepository;

    // Obtener todos los vehículos
    public Iterable<Vehiculo> list() {
        return vehiculoRepository.findAll();
    }

    // Buscar un vehículo por ID
    public Vehiculo findById(Long id) {
        return vehiculoRepository.findById(id).orElse(null); // Retorna null si no se encuentra
    }

    // Buscar un vehículo por matrícula
    public Vehiculo findByMatricula(String matricula) {
        return vehiculoRepository.findByMatricula(matricula);
    }

    // Crear un nuevo vehículo
    public Vehiculo create(Vehiculo vehiculo) {
        return vehiculoRepository.save(vehiculo);
    }

    // Actualizar un vehículo
    public Vehiculo update(Long id, Vehiculo vehiculo) {
        if (vehiculoRepository.existsById(id)) {
            vehiculo.setId(id);
            return vehiculoRepository.save(vehiculo);
        }
        return null;
    }

    // Eliminar un vehículo
    public void remove(Long id) {
        vehiculoRepository.deleteById(id);
    }
}

