package com.pablo.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pablo.models.Garaje;
import com.pablo.models.GarajeDTO;
import com.pablo.services.GarajeService;

@RestController
@RequestMapping("/garajes")
public class GarajeController {

    @Autowired
    private GarajeService garajeService;

    // Obtener todos los garajes
    @GetMapping
    public Iterable<Garaje> getAll() {
        return garajeService.list();
    }

    // Obtener un garaje por ID
    @GetMapping("/{id}")
    public ResponseEntity<Garaje> getById(@PathVariable Long id) {
        Optional<Garaje> garaje = garajeService.findById(id);
        return garaje.map(ResponseEntity::ok) // Devuelve el garaje con estado 200 si lo encuentra
                     .orElseGet(() -> ResponseEntity.notFound().build()); // Retorna 404 si no lo encuentra
    }

    // Obtener un garaje por dirección
    @GetMapping("/direccion/{direccion}")
    public ResponseEntity<Garaje> getByDireccion(@PathVariable String direccion) {
        Optional<Garaje> garaje = garajeService.findByDireccion(direccion);
        return garaje.map(ResponseEntity::ok)
                     .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear un nuevo garaje
    @PostMapping
    public ResponseEntity<Garaje> create(@RequestBody GarajeDTO garajeDTO) {
        // Convertir el DTO a una entidad Garaje
        Garaje nuevoGaraje = new Garaje(
                garajeDTO.getDireccion(),
                garajeDTO.getNombre(),
                garajeDTO.getCapacidad()
        );
        Garaje garajeCreado = garajeService.create(nuevoGaraje);
        return ResponseEntity.ok(garajeCreado); // Devuelve el garaje creado con código HTTP 200
    }

    // Actualizar un garaje por ID
    @PutMapping("/{id}")
    public ResponseEntity<Garaje> update(@PathVariable Long id, @RequestBody Garaje garaje) {
        Garaje garajeActualizado = garajeService.update(id, garaje);
        if (garajeActualizado == null) {
            return ResponseEntity.notFound().build(); // Retorna 404 si no encuentra el garaje
        }
        return ResponseEntity.ok(garajeActualizado); // Devuelve el garaje actualizado
    }

    // Eliminar un garaje por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        boolean eliminado = garajeService.remove(id);
        if (eliminado) {
            return ResponseEntity.noContent().build(); // Retorna 204 No Content si se eliminó correctamente
        } else {
            return ResponseEntity.notFound().build(); // Retorna 404 si no se encuentra el garaje
        }
    }
}

