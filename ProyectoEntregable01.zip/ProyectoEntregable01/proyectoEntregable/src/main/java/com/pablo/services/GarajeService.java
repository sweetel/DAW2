package com.pablo.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pablo.models.Garaje;
import com.pablo.repositories.IGarajeRepository;

@Service
public class GarajeService {

    @Autowired
    private IGarajeRepository garajeRepository;

    // Listar todos los garajes
    public Iterable<Garaje> list() {
        return garajeRepository.findAll();
    }

    // Buscar un garaje por ID
    public Optional<Garaje> findById(Long id) {
        return garajeRepository.findById(id);
    }

    // Buscar un garaje por dirección
    public Optional<Garaje> findByDireccion(String direccion) {
        return garajeRepository.findByDireccion(direccion);
    }

    // Crear un nuevo garaje
    public Garaje create(Garaje garaje) {
        return garajeRepository.save(garaje);
    }

    // Actualizar un garaje existente
    public Garaje update(Long id, Garaje garaje) {
        if (garajeRepository.existsById(id)) {
            garaje.setId(id); // Asegurarse de que el ID del garaje a actualizar es el correcto
            return garajeRepository.save(garaje);
        }
        return null;
    }

    // Eliminar un garaje por ID
    public boolean remove(Long id) {
        if (garajeRepository.existsById(id)) {
            garajeRepository.deleteById(id);
            return true; // Retorna true si se eliminó correctamente
        }
        return false; // Retorna false si el garaje no existe
    }
}
