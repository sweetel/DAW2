package com.pablo.repositories;

import com.pablo.models.Vehiculo;
import org.springframework.data.repository.CrudRepository;

public interface IVehiculoRepository extends CrudRepository<Vehiculo, Long> {

    // Buscar un vehículo por matrícula
    Vehiculo findByMatricula(String matricula);
}
