package com.pablo.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pablo.models.Conductor;
import com.pablo.models.ConductorDTO;
import com.pablo.services.ConductorService;

@RestController
@RequestMapping("/conductores")
public class ConductorController {

    @Autowired
    private ConductorService conductorService;

    // Obtener todos los conductores
    @GetMapping
    public Iterable<ConductorDTO> list() {
        Iterable<Conductor> conductores = conductorService.list();
        return convertToDtoList(conductores); // Convertimos la lista de conductores a DTOs
    }

    // Buscar un conductor por ID
    @GetMapping("/{id}")
    public ResponseEntity<ConductorDTO> findById(@PathVariable Long id) {
        Conductor conductor = conductorService.findById(id);
        if (conductor == null) {
            return ResponseEntity.notFound().build(); // Retorna 404 si no se encuentra el conductor
        }
        return ResponseEntity.ok(convertToDto(conductor)); // Convertimos el conductor a DTO
    }

    // Buscar un conductor por DNI
    @GetMapping("/dni/{dni}")
    public ResponseEntity<ConductorDTO> findByDni(@PathVariable String dni) {
        Conductor conductor = conductorService.findByDni(dni);
        if (conductor == null) {
            return ResponseEntity.notFound().build(); // Retorna 404 si no se encuentra el conductor
        }
        return ResponseEntity.ok(convertToDto(conductor)); // Convertimos el conductor a DTO
    }

    // Crear un nuevo conductor
    @PostMapping
    public ResponseEntity<ConductorDTO> create(@RequestBody ConductorDTO conductorDTO) {
        Conductor conductor = convertToEntity(conductorDTO); // Convertimos el DTO a entidad
        Conductor createdConductor = conductorService.create(conductor);
        return ResponseEntity.status(201).body(convertToDto(createdConductor)); // Convertimos la entidad a DTO
    }

    // Actualizar un conductor
    @PutMapping("/{id}")
    public ResponseEntity<ConductorDTO> update(@PathVariable Long id, @RequestBody ConductorDTO conductorDTO) {
        Conductor conductor = convertToEntity(conductorDTO); // Convertimos el DTO a entidad
        Conductor updatedConductor = conductorService.update(id, conductor);
        if (updatedConductor == null) {
            return ResponseEntity.notFound().build(); // Retorna 404 si el conductor no existe
        }
        return ResponseEntity.ok(convertToDto(updatedConductor)); // Convertimos la entidad a DTO
    }

    // Eliminar un conductor
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remove(@PathVariable Long id) {
        conductorService.remove(id);
        return ResponseEntity.noContent().build(); // Retorna 204 si el conductor se elimina correctamente
    }

    // Métodos para convertir entre Conductor y ConductorDTO

    private ConductorDTO convertToDto(Conductor conductor) {
        ConductorDTO dto = new ConductorDTO();
        dto.setId(conductor.getId());
        dto.setNombre(conductor.getNombre());
        dto.setApellido(conductor.getApellido());
        dto.setDni(conductor.getDni());
        return dto;
    }

    private Conductor convertToEntity(ConductorDTO conductorDTO) {
        Conductor conductor = new Conductor();
        conductor.setId(conductorDTO.getId());
        conductor.setNombre(conductorDTO.getNombre());
        conductor.setApellido(conductorDTO.getApellido());
        conductor.setDni(conductorDTO.getDni());
        return conductor;
    }

    private Iterable<ConductorDTO> convertToDtoList(Iterable<Conductor> conductores) {
        List<ConductorDTO> dtoList = new ArrayList<>();
        for (Conductor conductor : conductores) {
            dtoList.add(convertToDto(conductor)); // Convertimos cada Conductor a ConductorDTO
        }
        return dtoList;
    }
}


