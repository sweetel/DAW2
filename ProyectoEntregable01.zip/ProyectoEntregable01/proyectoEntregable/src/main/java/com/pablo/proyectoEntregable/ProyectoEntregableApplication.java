package com.pablo.proyectoEntregable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"com.pablo"})
@EntityScan(basePackages = {"com.pablo.models"}) // Escaneo de entidades
@EnableJpaRepositories(basePackages = {"com.pablo.repositories"}) 
public class ProyectoEntregableApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoEntregableApplication.class, args);
	}

}
