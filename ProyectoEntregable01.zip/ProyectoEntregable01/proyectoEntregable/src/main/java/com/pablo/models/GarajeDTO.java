package com.pablo.models;

public class GarajeDTO {

    private String direccion;
    private String nombre;
    private int capacidad;

    // Constructor vacío
    public GarajeDTO() {}

    // Constructor con parámetros
    public GarajeDTO(String direccion, String nombre, int capacidad) {
        this.direccion = direccion;
        this.nombre = nombre;
        this.capacidad = capacidad;
    }

    // Getters y setters
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }
}
