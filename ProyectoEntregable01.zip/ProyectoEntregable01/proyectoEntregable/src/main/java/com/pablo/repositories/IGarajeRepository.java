package com.pablo.repositories;

import com.pablo.models.Garaje;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IGarajeRepository extends CrudRepository<Garaje, Long> {
    Optional<Garaje> findByDireccion(String direccion);
}
