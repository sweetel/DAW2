package com.pablo.services;

import com.pablo.models.Conductor;
import com.pablo.repositories.IConductorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConductorService {

    @Autowired
    private IConductorRepository conductorRepository;

    // Obtener todos los conductores
    public Iterable<Conductor> list() {
        return conductorRepository.findAll();
    }

    // Buscar un conductor por ID
    public Conductor findById(Long id) {
        return conductorRepository.findById(id).orElse(null);  // Usamos orElse(null) para manejar el Optional
    }

    // Buscar un conductor por DNI
    public Conductor findByDni(String dni) {
        return conductorRepository.findByDni(dni);
    }

    // Crear un nuevo conductor
    public Conductor create(Conductor conductor) {
        return conductorRepository.save(conductor);
    }

    // Actualizar un conductor
    public Conductor update(Long id, Conductor conductor) {
        if (conductorRepository.existsById(id)) {
            conductor.setId(id);
            return conductorRepository.save(conductor);
        }
        return null;
    }

    // Eliminar un conductor
    public void remove(Long id) {
        conductorRepository.deleteById(id);
    }
}

