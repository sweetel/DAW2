package com.pablo.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pablo.models.Vehiculo;
import com.pablo.models.VehiculoDTO;
import com.pablo.services.VehiculoService;

@RestController
@RequestMapping("/vehiculos")
public class VehiculoController {

    @Autowired
    private VehiculoService vehiculoService;

    // Obtener todos los vehículos
    @GetMapping
    public Iterable<VehiculoDTO> list() {
        Iterable<Vehiculo> vehiculos = vehiculoService.list();
        return convertToDtoList(vehiculos);  // Convertimos la lista de vehículos a DTOs
    }

    // Buscar un vehículo por ID
    @GetMapping("/{id}")
    public ResponseEntity<VehiculoDTO> findById(@PathVariable Long id) {
        Vehiculo vehiculo = vehiculoService.findById(id);
        if (vehiculo == null) {
            return ResponseEntity.notFound().build(); // Retorna 404 si no se encuentra el vehículo
        }
        return ResponseEntity.ok(convertToDto(vehiculo));  // Convertimos el vehículo a DTO
    }

    // Buscar un vehículo por matrícula
    @GetMapping("/matricula/{matricula}")
    public ResponseEntity<VehiculoDTO> findByMatricula(@PathVariable String matricula) {
        Vehiculo vehiculo = vehiculoService.findByMatricula(matricula);
        if (vehiculo == null) {
            return ResponseEntity.notFound().build(); // Retorna 404 si no se encuentra el vehículo
        }
        return ResponseEntity.ok(convertToDto(vehiculo));  // Convertimos el vehículo a DTO
    }

    // Crear un nuevo vehículo
    @PostMapping
    public ResponseEntity<VehiculoDTO> create(@RequestBody VehiculoDTO vehiculoDTO) {
        Vehiculo vehiculo = convertToEntity(vehiculoDTO);  // Convertimos el DTO a entidad
        Vehiculo createdVehiculo = vehiculoService.create(vehiculo);
        return ResponseEntity.status(201).body(convertToDto(createdVehiculo));  // Convertimos la entidad a DTO
    }

    // Actualizar un vehículo
    @PutMapping("/{id}")
    public ResponseEntity<VehiculoDTO> update(@PathVariable Long id, @RequestBody VehiculoDTO vehiculoDTO) {
        Vehiculo vehiculo = convertToEntity(vehiculoDTO);  // Convertimos el DTO a entidad
        Vehiculo updatedVehiculo = vehiculoService.update(id, vehiculo);
        if (updatedVehiculo == null) {
            return ResponseEntity.notFound().build(); // Retorna 404 si el vehículo no existe
        }
        return ResponseEntity.ok(convertToDto(updatedVehiculo));  // Convertimos la entidad a DTO
    }

    // Eliminar un vehículo
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remove(@PathVariable Long id) {
        vehiculoService.remove(id);
        return ResponseEntity.noContent().build();  // Retorna 204 si el vehículo se elimina correctamente
    }

    // Métodos para convertir entre Vehiculo y VehiculoDTO

    private VehiculoDTO convertToDto(Vehiculo vehiculo) {
        VehiculoDTO dto = new VehiculoDTO();
        dto.setId(vehiculo.getId());
        dto.setMatricula(vehiculo.getMatricula());
        dto.setModelo(vehiculo.getModelo());
        dto.setMarca(vehiculo.getMarca());
        dto.setGarajeId(vehiculo.getGaraje() != null ? vehiculo.getGaraje().getId() : null);
        return dto;
    }

    private Vehiculo convertToEntity(VehiculoDTO vehiculoDTO) {
        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setId(vehiculoDTO.getId());
        vehiculo.setMatricula(vehiculoDTO.getMatricula());
        vehiculo.setModelo(vehiculoDTO.getModelo());
        vehiculo.setMarca(vehiculoDTO.getMarca());
        // Aquí deberías asignar el garaje correctamente, dependiendo de cómo quieras gestionarlo
        return vehiculo;
    }

    private Iterable<VehiculoDTO> convertToDtoList(Iterable<Vehiculo> vehiculos) {
        List<VehiculoDTO> dtoList = new ArrayList<>();
        for (Vehiculo vehiculo : vehiculos) {
            dtoList.add(convertToDto(vehiculo));  // Convertimos cada Vehiculo a VehiculoDTO
        }
        return dtoList;
    }
}
